

def handler(event, context):
    return {'status': 'success'}
